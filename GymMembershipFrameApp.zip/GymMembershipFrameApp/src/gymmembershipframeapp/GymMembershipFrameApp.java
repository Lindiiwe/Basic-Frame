package gymmembershipframeapp;

import za.ac.tut.ui.GymMembershipFrame;

public class GymMembershipFrameApp {

    public static void main(String[] args) {
        //instantiation
        new GymMembershipFrame();
    }
    
}

