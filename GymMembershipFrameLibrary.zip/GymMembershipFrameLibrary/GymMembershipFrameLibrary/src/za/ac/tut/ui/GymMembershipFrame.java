package za.ac.tut.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import za.ac.tut.memebership.Member;

public class GymMembershipFrame extends JFrame{
    
    private JPanel headingPnl;
    private JPanel clientPnl;
    private JPanel namePnl;
    private JPanel surnamePnl;
    private JPanel idNoPnl;
    private JPanel genderPnl;
    private JPanel contractPnl;
    private JPanel personalTrainerOptionPnl;
    private JPanel membershipPnl;
    private JPanel commentsPnl;
    private JPanel btnPnl;
    private JPanel headingClientCombinedPnl;
    private JPanel membershipCommentsCombinesPnl;
    private JPanel mainPnl;
    
    //Labels
    private JLabel headinLbl;
    private JLabel clientLbl;
    private JLabel nameLbl;
    private JLabel surnameLbl;
    private JLabel idNoLbl;
    private JLabel genderLbl;
    private JLabel contractTypeLbl;
    private JLabel personalTrainerLbl;
    
    //textfields
    private JTextField nameTxtFld;
    private JTextField surnameTxtFld;
    private JTextField idNoTxtFld;
    
    //combobox
    private JComboBox genderComboBox;
    
    //Radio Button
    private JRadioButton monthToMonthRadBtn;
    private JRadioButton sixMonthsRadBtn;
    private JRadioButton annualRadBtn;
    
    //Checkbox
    private JCheckBox personaltrainerChkBx;
    
    //buttongroup
    private ButtonGroup btnGrp;
    
    //textarea
    private JTextArea commentsArea;
    
    //Scroll
    private JScrollPane scrollableTxtArea;
    
    //private button
    private JButton registerbtn;
    private JButton clearbtn;
    private JButton exitbtn;
    private JButton searchbtn;
    private JButton removebtn;
    private JButton updatebtn;
    private JButton displaybtn;
    
    //list 
    private ArrayList<Member> members;
    
    //construct the gui
    public GymMembershipFrame(){
        
        //set the frame
        setTitle("Gym Membership");
        setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JFrame.setDefaultLookAndFeelDecorated(true);
        
        //Create a list for members
        members = new ArrayList<>();
        
        //create panels 
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        clientPnl = new JPanel(new GridLayout(4,1,1,1));
        clientPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Client details"));
        
        namePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        surnamePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        idNoPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        contractPnl =  new JPanel(new FlowLayout(FlowLayout.LEFT));
        personalTrainerOptionPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        membershipPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        membershipPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1), "Contract options"));
        
        commentsPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        btnPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headingClientCombinedPnl = new JPanel(new BorderLayout());
        membershipCommentsCombinesPnl = new JPanel(new BorderLayout());
        mainPnl = new JPanel(new BorderLayout());
        
        //Create Labels
        headinLbl = new JLabel("Membership Form");
        headinLbl.setFont(new Font(Font.SANS_SERIF, Font.ITALIC + Font.BOLD, 20));
        headinLbl.setForeground(Color.BLUE);
        headinLbl.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
        
        nameLbl = new JLabel("Name:       ");
        surnameLbl = new JLabel("Surname: ");
        idNoLbl = new JLabel("Id no:         ");
        genderLbl = new JLabel("Gender:     ");
        contractTypeLbl = new JLabel("Type of contract: ");
        personalTrainerLbl = new JLabel("Select the checkboc if you need a personal trainer ");
        
        
        //create textfields
        nameTxtFld = new JTextField(10);
        surnameTxtFld = new JTextField(10);
        idNoTxtFld = new JTextField(10);
        
        //create combobox
        genderComboBox = new JComboBox();
        genderComboBox.addItem("Male");
        genderComboBox.addItem("Female");
        
        //Create radio buttons
        monthToMonthRadBtn = new JRadioButton("Month-to-month");
        sixMonthsRadBtn = new JRadioButton("Six months");
        annualRadBtn = new JRadioButton("Annual");
        
        //create check box
        personaltrainerChkBx = new JCheckBox();
        
        //create button group
        btnGrp = new ButtonGroup();
        btnGrp.add(monthToMonthRadBtn);
        btnGrp.add(sixMonthsRadBtn);
        btnGrp.add(annualRadBtn);
        
        //create text area
        commentsArea = new JTextArea(15,50);
        commentsArea.setEditable(false);
        commentsArea.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1), "Member(s) details"));
        
        scrollableTxtArea = new JScrollPane(commentsArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        
        //create button
        registerbtn = new JButton("REGISTER");
        registerbtn.addActionListener(new RegisterBtnListener());
        
        searchbtn = new JButton("SEARCH");
        searchbtn.addActionListener(new SearchBtnListener());
        
        removebtn = new JButton("REMOVE");
        removebtn.addActionListener(new RemoveBtnListener());
        
        updatebtn = new JButton("UPDATE");
        updatebtn.addActionListener(new UpdateBtnListener());
        
        displaybtn = new JButton("DISPLAY ALL");
        displaybtn.addActionListener(new DisplayAllBtnListener());
        
        clearbtn = new JButton("CLEAR");
        clearbtn.addActionListener(new ClearBtnListener());
        
        exitbtn = new JButton("EXIT");
        exitbtn.addActionListener(new ExitBtnListener());
        
        //add components to panels
        headingPnl.add(headinLbl); //--> firt collective panel
        
        namePnl.add(nameLbl);
        namePnl.add(nameTxtFld);
        
        surnamePnl.add(surnameLbl);
        surnamePnl.add(surnameTxtFld);
        
        idNoPnl.add(idNoLbl);
        idNoPnl.add(idNoTxtFld);
        
        genderPnl.add(genderLbl);
        genderPnl.add(genderComboBox);
        
        clientPnl.add(namePnl); //--> second collective panel
        clientPnl.add(surnamePnl);
        clientPnl.add(idNoPnl);
        clientPnl.add(genderPnl);
        
        headingClientCombinedPnl.add(headingPnl, BorderLayout.NORTH);
        headingClientCombinedPnl.add(clientPnl, BorderLayout.CENTER);
        
        contractPnl.add(contractTypeLbl);
        contractPnl.add(monthToMonthRadBtn); //--> third collective panel
        contractPnl.add(sixMonthsRadBtn);
        contractPnl.add(annualRadBtn);
        
        personalTrainerOptionPnl.add(personalTrainerLbl);
        personalTrainerOptionPnl.add(personaltrainerChkBx);
        
        membershipPnl.add(contractPnl);
        membershipPnl.add(personalTrainerOptionPnl);
        
        commentsPnl.add(scrollableTxtArea); //-->forth collective panel
        
        membershipCommentsCombinesPnl.add(membershipPnl, BorderLayout.NORTH);
        membershipCommentsCombinesPnl.add(commentsPnl, BorderLayout.CENTER);
        
        btnPnl.add(registerbtn); //-->fifth collective panel
        btnPnl.add(searchbtn);
        btnPnl.add(updatebtn);
        btnPnl.add(removebtn);
        btnPnl.add(displaybtn);
        btnPnl.add(clearbtn);
        btnPnl.add(exitbtn);
        
        mainPnl.add(headingClientCombinedPnl, BorderLayout.NORTH);
        mainPnl.add(membershipCommentsCombinesPnl, BorderLayout.CENTER);
        mainPnl.add(btnPnl, BorderLayout.SOUTH);
        
        add(mainPnl);
        pack();
        setResizable(false);
        setVisible(true);   
    }
    
    private class RegisterBtnListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent ae){
            //read input
            String name = nameTxtFld.getText();
            String surname = surnameTxtFld.getText();
            String idNo = idNoTxtFld.getText();
            String gender = (String)genderComboBox.getSelectedItem();
            Boolean isPersonTrainerSelected = personaltrainerChkBx.isSelected();
            String contractType = "Month-to-month";
            
            if(sixMonthsRadBtn.isSelected()){
                contractType = "Six Months";
            }else{
                if(annualRadBtn.isSelected()){
                    contractType = "Annual";
                }
            }
            
            //Create a member 
            Member member = new Member(name, surname, idNo, gender, contractType, isPersonTrainerSelected);
            
            //add a member to the list
            members.add(member);
            
            //add a confirmation message to the text area
            commentsArea.setText("This member has been succesfully added:\n");
            
        }
    }
    
    private class SearchBtnListener implements ActionListener{
         
        @Override
        public void actionPerformed(ActionEvent e) {
            String  idNo = idNoTxtFld.getText();
             for(Member member : members){
                 if(member.getIdNo().equals(idNo)){
                    commentsArea.append("Member Found:\n" + member.toString() + "\n");
                    return;
                 }
             }
             commentsArea.append("Member with ID " + idNo + " not found.\n");
        }
    } 
   
   private class UpdateBtnListener implements ActionListener{
       @Override
       public void actionPerformed(ActionEvent ae){
         
           String idNo = idNoTxtFld.getText();
           for(Member member : members){
               if(member.getIdNo().equals(idNo)){
                   member.setName(nameTxtFld.getText());
                   member.setSurname(surnameTxtFld.getText());
                   member.setGender((String)genderComboBox.getSelectedItem());
                   String contractType = "Month-to-month";
                   if(sixMonthsRadBtn.isSelected()){
                       contractType = "six months";
                   }
                   else if(annualRadBtn.isSelected()){
                     contractType = "Annual";
                   }
                   member.setContractType(contractType);
                   member.setIsPersonalTrainerNeeded(personaltrainerChkBx.isSelected());
                   commentsArea.append("Member updated:\n" + member.toString() + "\n");
                   return;
               }    
           }
           commentsArea.append("Member with ID " + idNo + " not found.\n");
       }
   }   
       
    public class RemoveBtnListener implements ActionListener {
            
           @Override
           public void actionPerformed(ActionEvent ae){
              String idNo = idNoTxtFld.getText();
              for(Member member : members){
                 if(member.getIdNo().equals(idNo)){
                    members.remove(member);
                    commentsArea.append("Member Removed:\n" + member.toString()+ "\n");
                    return;
                 }
              }
              commentsArea.append("Member with ID " + idNo + " not found.\n");
           }
    }
    
    public class DisplayAllBtnListener implements ActionListener{
       
        @Override
        public void actionPerformed(ActionEvent ae){
           commentsArea.setText("");
           for(Member member : members){
             commentsArea.append(member.toString() + "\n");
           }
        }
    }
       
    private class ClearBtnListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent ae){
            //clear the fields
            nameTxtFld.setText("");
            surnameTxtFld.setText("");
            idNoTxtFld.setText("");
            personaltrainerChkBx.setSelected(false);
            btnGrp.clearSelection();
            commentsArea.setText("");
            
            //set focus back to the name text field
            nameTxtFld.setFocusable(true);
        }
      }
       
    public class ExitBtnListener implements ActionListener{
      
       @Override
       public void actionPerformed(ActionEvent ae){
           //exit
           System.exit(1);
       }
   
   }
   
}
