package basicframeapp;

public class BasicFrameApp {

    public static void main(String[] args) {
      MyFirstFrame myFrame;
    }
    
}
